bl_info = {
    "name": "Export Image/Sequence Composite",
    "blender": (2, 80, 0),
    "category": "Import-Export",
    "author": "Tech Boy JaTiX",
    "version": (1, 0, 0),
    "description": "Composite Image with Alpha",
}

import bpy
import os

class ExportCompositeOperator(bpy.types.Operator):
    bl_idname = "export.composite_img_seq"
    bl_label = "Export Composite Image/Sequence"
    bl_options = {'REGISTER'}

    single_image: bpy.props.BoolProperty(
        name="Single Image", 
        description="Export one image, or a sequence",
        default=True
    )

    color_path: bpy.props.StringProperty(
        name="RGB Path/Folder",
        description="Folder for sequence or file for single image",
        subtype='FILE_PATH'  # will show file select, but user can type folder for sequence
    )
    alpha_path: bpy.props.StringProperty(
        name="Alpha Path/Folder",
        description="Folder for sequence or file for single image",
        subtype='FILE_PATH'
    )
    export_path: bpy.props.StringProperty(
        name="Export Path/Folder",
        description="Folder for sequence or file for single image",
        subtype='FILE_PATH'
    )
    export_format: bpy.props.EnumProperty(
        name="Export Format",
        description="Choose output image format",
        items=[
            ('PNG', 'PNG (.png)', 'PNG image'),
            ('JPEG', 'JPEG (.jpg)', 'JPEG image'),
            ('TIFF', 'TIFF (.tif)', 'TIFF image')
        ],
        default='PNG'
    )
    start_frame: bpy.props.IntProperty(
        name="Start Frame",
        description="First frame index (only for sequence)",
        default=0,
        min=0
    )
    end_frame: bpy.props.IntProperty(
        name="End Frame",
        description="Last frame index (only for sequence)",
        default=0,
        min=0
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "single_image")
        layout.prop(self, "color_path")
        layout.prop(self, "alpha_path")
        layout.prop(self, "export_path")
        layout.prop(self, "export_format")
        if not self.single_image:
            layout.prop(self, "start_frame")
            layout.prop(self, "end_frame")

    def execute(self, context):
        scene = context.scene
        scene.use_nodes = True
        tree = scene.node_tree
        tree.nodes.clear()

        color_node = tree.nodes.new("CompositorNodeImage")
        alpha_node = tree.nodes.new("CompositorNodeImage")
        set_alpha = tree.nodes.new("CompositorNodeSetAlpha")
        comp_node = tree.nodes.new("CompositorNodeComposite")
        viewer = tree.nodes.new("CompositorNodeViewer")

        ext = self.export_format.lower()
        ext = ext if ext != 'jpeg' else 'jpg'

        if self.single_image:
            color_img = bpy.data.images.load(self.color_path)
            alpha_img = bpy.data.images.load(self.alpha_path)
            color_node.image = color_img
            alpha_node.image = alpha_img

            tree.links.new(color_node.outputs[0], set_alpha.inputs[0])
            tree.links.new(alpha_node.outputs[0], set_alpha.inputs[1])
            tree.links.new(set_alpha.outputs[0], comp_node.inputs[0])
            tree.links.new(set_alpha.outputs[0], viewer.inputs[0])

            bpy.ops.render.render()
            out_path = self.export_path
            if not out_path.endswith(f".{ext}"):
                out_path += f".{ext}"
            bpy.data.images['Viewer Node'].save_render(filepath=out_path)

            bpy.data.images.remove(color_img)
            bpy.data.images.remove(alpha_img)
        else:
            color_files = sorted([f for f in os.listdir(self.color_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tif', '.exr'))])
            alpha_files = sorted([f for f in os.listdir(self.alpha_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tif', '.exr'))])
            # correct end_frame if it's too large
            length = min(len(color_files), len(alpha_files))
            sf = max(self.start_frame, 0)
            ef = min(self.end_frame+1, length) if self.end_frame >= self.start_frame else length
            if sf >= length or ef > length or sf >= ef:
                self.report({'ERROR'}, "Invalid start/end frame indices or no valid sequence images.")
                return {'CANCELLED'}

            for i in range(sf, ef):
                color_img = bpy.data.images.load(os.path.join(self.color_path, color_files[i]))
                alpha_img = bpy.data.images.load(os.path.join(self.alpha_path, alpha_files[i]))
                color_node.image = color_img
                alpha_node.image = alpha_img

                tree.links.clear()
                tree.links.new(color_node.outputs[0], set_alpha.inputs[0])
                tree.links.new(alpha_node.outputs[0], set_alpha.inputs[1])
                tree.links.new(set_alpha.outputs[0], comp_node.inputs[0])
                tree.links.new(set_alpha.outputs[0], viewer.inputs[0])

                bpy.ops.render.render()
                fname = f"composite_{i:04d}.{ext}"
                out_path = (
                    os.path.join(self.export_path, fname)
                    if os.path.isdir(self.export_path)
                    else self.export_path + f"_{i:04d}.{ext}"
                )
                try:
                    bpy.data.images['Viewer Node'].save_render(filepath=out_path)
                except Exception as e:
                    self.report({'ERROR'}, f"Failed at frame {i}: {str(e)}")
                bpy.data.images.remove(color_img)
                bpy.data.images.remove(alpha_img)
            
            self.report({'INFO'}, f"Exported frames {sf} to {ef-1} to {self.export_path} as {self.export_format}.")
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

def menu_func(self, context):
    self.layout.operator(ExportCompositeOperator.bl_idname)

def register():
    bpy.utils.register_class(ExportCompositeOperator)
    bpy.types.TOPBAR_MT_file_export.append(menu_func)

def unregister():
    bpy.utils.unregister_class(ExportCompositeOperator)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func)

if __name__ == "__main__":
    register()
