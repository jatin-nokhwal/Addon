import bpy
from collections import Counter

class PROCESS_OT_Materials(bpy.types.Operator):
    """Operator to process materials and rename single-tile materials with UDIM suffix"""
    bl_idname = "object.process_materials"
    bl_label = "Process Per Tile Materials"
    bl_description = "Create unique materials for each UDIM tile and rename single-tile materials"
    
    def execute(self, context):
        try:
            processed_materials = process_materials()
            if processed_materials:
                delete_original_materials(processed_materials)
                self.report({'INFO'}, f"Successfully processed {len(processed_materials)} materials")
            else:
                self.report({'WARNING'}, "No materials needed processing")
        except Exception as e:
            self.report({'ERROR'}, f"Error processing materials: {str(e)}")
            return {'CANCELLED'}
        
        return {'FINISHED'}


def get_uv_tile_count(obj):
    if not obj.data.uv_layers.active:
        return set()
    
    uv_layer = obj.data.uv_layers.active
    uv_tiles = set()
    
    for poly in obj.data.polygons:
        for loop_index in poly.loop_indices:
            if loop_index < len(uv_layer.data):
                uv = uv_layer.data[loop_index].uv
                tile_x = int(uv.x)
                tile_y = int(uv.y)
                uv_tiles.add((tile_x, tile_y))
    
    return uv_tiles


def get_udim_tile_index(tile_coord):
    tile_x, tile_y = tile_coord
    return 1001 + tile_x + (tile_y * 10)


def sort_tile_coords_by_udim(tile_coords):
    tile_udim_pairs = [(coord, get_udim_tile_index(coord)) for coord in tile_coords]
    tile_udim_pairs.sort(key=lambda x: x[1])
    return [pair[0] for pair in tile_udim_pairs]


def get_material_tile_coord(obj, material):
    if not obj.data.uv_layers.active:
        return (0, 0)
    
    uv_layer = obj.data.uv_layers.active
    tile_coords = []
    
    for poly in obj.data.polygons:
        if poly.material_index < len(obj.material_slots):
            slot_material = obj.material_slots[poly.material_index].material
            if slot_material == material:
                if poly.loop_indices:
                    loop_index = poly.loop_indices[0]
                    if loop_index < len(uv_layer.data):
                        uv = uv_layer.data[loop_index].uv
                        tile_x = int(uv.x)
                        tile_y = int(uv.y)
                        tile_coords.append((tile_x, tile_y))
    
    if tile_coords:
        counter = Counter(tile_coords)
        return counter.most_common(1)[0][0]
    
    return (0, 0)


def duplicate_material_for_tiles(original_material, tile_coords):
    duplicated_materials = []
    sorted_tile_coords = sort_tile_coords_by_udim(tile_coords)
    
    print(f"Processing tiles in order: {[get_udim_tile_index(coord) for coord in sorted_tile_coords]}")
    
    for tile_coord in sorted_tile_coords:
        new_mat = original_material.copy()
        udim_index = get_udim_tile_index(tile_coord)
        new_mat.name = f"{original_material.name}_{udim_index}"
        duplicated_materials.append((tile_coord, new_mat))
        
        if len(sorted_tile_coords) > 10:
            print(f"Created material for UDIM {udim_index}")
    
    return duplicated_materials


def rename_single_tile_material(material, tile_coord):
    udim_index = get_udim_tile_index(tile_coord)
    new_name = f"{material.name}_{udim_index}"
    
    if new_name not in bpy.data.materials:
        material.name = new_name
        print(f"Renamed single-tile material: {material.name} (UDIM {udim_index})")
        return True
    else:
        print(f"Warning: Material name {new_name} already exists, keeping original name")
        return False


def process_materials():
    processed_materials = []
    
    for material in bpy.data.materials:
        material_name_parts = material.name.split("_")
        if material_name_parts and material_name_parts[-1].isdigit():
            udim_suffix = int(material_name_parts[-1])
            if 1001 <= udim_suffix <= 2000:
                print(f"Skipping already processed material: {material.name}")
                continue
            
        print(f"\n=== Processing material: {material.name} ===")
        
        linked_objects = []
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                for slot in obj.material_slots:
                    if slot.material == material:
                        linked_objects.append(obj)
                        break
        
        if not linked_objects:
            print(f"No objects linked to {material.name}, skipping")
            continue

        all_uv_tiles = set()
        for obj in linked_objects:
            obj_tiles = get_uv_tile_count(obj)
            if obj_tiles:
                all_uv_tiles.update(obj_tiles)
        
        uv_tile_count = len(all_uv_tiles)
        udim_indices = [get_udim_tile_index(coord) for coord in all_uv_tiles]
        print(f"Found {uv_tile_count} UV tiles for material '{material.name}': {sorted(udim_indices)}")
        
        if uv_tile_count == 1:
            tile_coord = next(iter(all_uv_tiles))
            if rename_single_tile_material(material, tile_coord):
                processed_materials.append(material.name)
                print(f"Renamed single-tile material {material.name} with UDIM suffix")
            continue
        
        if uv_tile_count == 0:
            print(f"Skipping material {material.name} - no UV tiles found")
            continue
        
        tile_to_mat_index = {}
        tile_materials = duplicate_material_for_tiles(material, all_uv_tiles)
        
        for obj in linked_objects:
            print(f"Processing object: {obj.name}")
            
            original_poly_materials = [poly.material_index for poly in obj.data.polygons]
            obj.data.materials.clear()
            
            for tile_coord, tile_mat in tile_materials:
                obj.data.materials.append(tile_mat)
                tile_to_mat_index[tile_coord] = len(obj.data.materials) - 1
            
            uv_layer = obj.data.uv_layers.active
            if uv_layer:
                assigned_count = 0
                for poly in obj.data.polygons:
                    if poly.loop_indices:
                        loop_index = poly.loop_indices[0]
                        if loop_index < len(uv_layer.data):
                            uv = uv_layer.data[loop_index].uv
                            tile_x = int(uv.x)
                            tile_y = int(uv.y)
                            tile_coord = (tile_x, tile_y)
                            
                            if tile_coord in tile_to_mat_index:
                                poly.material_index = tile_to_mat_index[tile_coord]
                                assigned_count += 1
                            else:
                                poly.material_index = original_poly_materials[poly.index] if poly.index < len(original_poly_materials) else 0
                
                print(f"Assigned materials to {assigned_count} polygons based on UV tiles")
        
        processed_materials.append(material.name)
        print(f"Successfully processed material: {material.name} -> {len(tile_materials)} tile materials")
    
    return processed_materials


def delete_original_materials(processed_material_names):
    deleted_count = 0
    for mat_name in processed_material_names:
        if mat_name in bpy.data.materials:
            original_mat = bpy.data.materials[mat_name]
            
            if original_mat.name != mat_name:
                continue
                
            still_used = False
            for obj in bpy.data.objects:
                if obj.type == 'MESH':
                    for slot in obj.material_slots:
                        if slot.material == original_mat:
                            still_used = True
                            break
                    if still_used:
                        break
            
            if not still_used and original_mat.users == 0:
                print(f"Deleting original material: {mat_name}")
                bpy.data.materials.remove(original_mat)
                deleted_count += 1
            elif still_used:
                print(f"Material {mat_name} still in use, skipping deletion")
            else:
                print(f"Material {mat_name} has {original_mat.users} users, skipping deletion")
    
    print(f"Deleted {deleted_count} original materials")


class VIEW3D_PT_Materials(bpy.types.Panel):
    """Panel for Material Processing Tools"""
    bl_label = "UDIM Material Processor"
    bl_idname = "VIEW3D_PT_Materials"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'

    def draw(self, context):
        layout = self.layout
        layout.operator("object.process_materials", text="Process Per Tile Materials", icon='MATERIAL')
