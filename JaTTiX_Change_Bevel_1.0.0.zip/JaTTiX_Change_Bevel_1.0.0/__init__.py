bl_info = {
    "name": "JaTiX Change Bevel",
    "author": "Tech Boy JaTiX",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > N-Panel > JaTiX Tools",
    "description": "Adjust or remove bevels on selected edge loops using a simple slider.",
    "category": "3D View",
}

import bpy
import bmesh
import math
from math import *
import mathutils as mathu
from mathutils import Vector, Matrix


# =========================================================
# Inlined loop tools (from mi_looptools.py, trimmed)
# =========================================================

def edgekey(edge):
    return tuple(sorted([edge.verts[0].index, edge.verts[1].index]))


def dict_vert_verts(edge_keys):
    vert_verts = {}
    for ek in edge_keys:
        for i in range(2):
            if ek[i] in vert_verts:
                vert_verts[ek[i]].append(ek[1 - i])
            else:
                vert_verts[ek[i]] = [ek[1 - i]]
    return vert_verts


def get_connected_selections(edge_keys):
    vert_verts = dict_vert_verts(edge_keys)
    loops = []

    while len(vert_verts) > 0:
        loop = [next(iter(vert_verts.keys()))]
        growing = True
        flipped = False

        while growing:
            if loop[-1] not in vert_verts:
                if not flipped:
                    loop.reverse()
                    flipped = True
                else:
                    growing = False
            else:
                extended = False
                for i, next_vert in enumerate(vert_verts[loop[-1]]):
                    if next_vert not in loop:
                        vert_verts[loop[-1]].pop(i)
                        if len(vert_verts[loop[-1]]) == 0:
                            del vert_verts[loop[-1]]

                        if next_vert in vert_verts:
                            if len(vert_verts[next_vert]) == 1:
                                del vert_verts[next_vert]
                            else:
                                vert_verts[next_vert].remove(loop[-1])

                        loop.append(next_vert)
                        extended = True
                        break

                if not extended:
                    if not flipped:
                        loop.reverse()
                        flipped = True
                    else:
                        growing = False

        if loop[0] in vert_verts and loop[-1] in vert_verts[loop[0]]:
            if len(vert_verts[loop[0]]) == 1:
                del vert_verts[loop[0]]
            else:
                vert_verts[loop[0]].remove(loop[-1])

            if len(vert_verts[loop[-1]]) == 1:
                del vert_verts[loop[-1]]
            else:
                vert_verts[loop[-1]].remove(loop[0])

            loop = [loop, True]
        else:
            loop = [loop, False]

        loops.append(loop)

    return loops


def get_connected_input(bm):
    edge_keys = [edgekey(edge) for edge in bm.edges
                 if edge.select and not edge.hide]
    loops = get_connected_selections(edge_keys)
    return loops


def check_loops(loops, bm_mod):
    valid_loops = []
    for loop, circular in loops:
        if len(loop) < 3:
            continue
        stacked = True
        for i in range(len(loop) - 1):
            if (bm_mod.verts[loop[i]].co -
                    bm_mod.verts[loop[i + 1]].co).length > 1e-6:
                stacked = False
                break
        if stacked:
            continue
        valid_loops.append([loop, circular])
    return valid_loops


# =========================================================
# Change Bevel operator (with slower factor)
# =========================================================

class JATIX_OT_ChangeBevel(bpy.types.Operator):
    """Change bevel amount on selected corner / edges"""
    bl_idname = "jatix.change_bevel"
    bl_label = "Change Bevel"
    bl_description = "Change bevel width on selected loops or edges"
    bl_options = {'REGISTER', 'UNDO'}

    value: bpy.props.FloatProperty(
        name="Change Bevel",
        description="0 = remove bevel, higher = keep/move bevel",
        default=1.0,
        min=0.0,
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and
                obj.type == 'MESH' and
                context.mode == 'EDIT_MESH')

    def invoke(self, context, event):
        self.value = context.scene.jatix_change_bevel
        return self.execute(context)

    def execute(self, context):
        active_obj = context.active_object
        bm = bmesh.from_edit_mesh(active_obj.data)
        bm.verts.ensure_lookup_table()

        # remap slider to slower factor
        raw = self.value
        factor = raw * raw  # change to raw**3 for even slower response

        loops = get_connected_input(bm)
        loops = check_loops(loops, bm)
        b_edges = [edge for edge in bm.edges if edge.select]

        if factor == 1.0:
            return {'CANCELLED'}

        degree_90 = 1.5708

        # ---------- LOOP MODE ----------
        if loops:
            for loop in loops:
                if loop[1] is True:
                    continue

                loop_verts = [bm.verts[ind] for ind in loop[0]]
                if len(loop_verts) < 4:
                    continue

                v1 = (loop_verts[1].co - loop_verts[0].co).normalized()
                v2 = (loop_verts[2].co - loop_verts[1].co).normalized()
                angle_1 = v1.angle(v2) / 2

                v3 = (loop_verts[-2].co - loop_verts[-1].co).normalized()
                v4 = (loop_verts[-3].co - loop_verts[-2].co).normalized()
                angle_2 = v3.angle(v4) / 2

                rot_dir = v1.cross(v2).normalized()
                rot_mat = Matrix.Rotation(-angle_1, 3, rot_dir)
                rot_mat_2 = Matrix.Rotation((angle_2 - degree_90), 3, rot_dir)

                v1_nor = ((rot_mat @ v1).normalized() * 10000.0) + loop_verts[0].co
                v3_nor = (rot_mat_2 @ v3).normalized()

                scale_pos = mathu.geometry.intersect_line_plane(
                    loop_verts[0].co, v1_nor,
                    loop_verts[-1].co, v3_nor,
                )
                if scale_pos is None:
                    continue

                for vert in loop_verts:
                    vert.co = scale_pos.lerp(vert.co, factor)

            if factor == 0.0:
                bpy.ops.mesh.merge(type='COLLAPSE')

            bm.normal_update()
            bmesh.update_edit_mesh(active_obj.data)

        # ---------- EDGE FALLBACK ----------
        elif b_edges:
            b_edges_pos = []
            b_edgess_ids = [edge.index for edge in b_edges]

            for edge in b_edges:
                verts = edge.verts

                if len(edge.link_faces) > 1:
                    linked_edges_0 = 0
                    linked_edges_1 = 0

                    for edge2 in edge.link_faces[0].edges:
                        if edge2.index in b_edgess_ids:
                            linked_edges_0 += 1
                    for edge2 in edge.link_faces[1].edges:
                        if edge2.index in b_edgess_ids:
                            linked_edges_1 += 1

                    if len(edge.link_faces[0].verts) > 4 or linked_edges_0 < 2:
                        ed_normal = edge.link_faces[1].normal
                    elif len(edge.link_faces[1].verts) > 4 or linked_edges_1 < 2:
                        ed_normal = edge.link_faces[0].normal
                    else:
                        ed_normal = edge.link_faces[0].normal.lerp(
                            edge.link_faces[1].normal, 0.5
                        )

                    fix_dir = ed_normal.cross(
                        (verts[0].co - verts[1].co).normalized()
                    )

                    v0_nor = mathu.geometry.intersect_line_plane(
                        verts[0].normal + (fix_dir * 2),
                        verts[0].normal - (fix_dir * 2),
                        Vector((0, 0, 0)),
                        fix_dir,
                    ).normalized()

                    v1_nor = mathu.geometry.intersect_line_plane(
                        verts[1].normal + (fix_dir * 2),
                        verts[1].normal - (fix_dir * 2),
                        Vector((0, 0, 0)),
                        fix_dir,
                    ).normalized()
                else:
                    v0_nor = verts[0].normal
                    v1_nor = verts[1].normal

                nor_dir = v0_nor.lerp(v1_nor, 0.5).normalized()
                side_dir_2 = (verts[0].co - verts[1].co).normalized()
                side_dir_2.negate()
                side_dir_1 = nor_dir.cross(side_dir_2).normalized()

                angle_between_1 = v0_nor.angle(nor_dir)
                angle_between_2 = v1_nor.angle(nor_dir)

                rot_mat = Matrix.Rotation(
                    (-angle_between_1 * 2) - degree_90, 3, side_dir_1
                )
                rot_mat_2 = Matrix.Rotation(
                    (angle_between_1 * 2) + (degree_90 * 2), 3, side_dir_1
                )

                dir_1 = ((rot_mat @ nor_dir).normalized() * 10000.0) + verts[0].co
                dir_2 = (rot_mat_2 @ nor_dir).normalized()

                scale_pos = mathu.geometry.intersect_line_plane(
                    verts[0].co, dir_1,
                    verts[1].co, dir_2,
                )
                if scale_pos is None:
                    continue

                b_edges_pos.append((verts[0], scale_pos))
                b_edges_pos.append((verts[1], scale_pos))

            for v_data in b_edges_pos:
                v_data[0].co = v_data[1].lerp(v_data[0].co, factor)

            if factor == 0.0:
                bpy.ops.mesh.merge(type='COLLAPSE')

            bm.normal_update()
            bmesh.update_edit_mesh(active_obj.data)

        return {'FINISHED'}


# =========================================================
# UI Panel
# =========================================================

class JATIX_PT_ChangeBevelPanel(bpy.types.Panel):
    bl_label = "JaTiX Change Bevel"
    bl_idname = "JATIX_PT_change_bevel_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "JaTiX Tools"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        box = layout.box()
        box.label(text="How to use", icon='INFO')
        box.label(text="1. Go to Edit Mode")
        box.label(text="2. Select beveled corner edges")
        box.label(text="3. Set value and click Apply")

        box2 = layout.box()
        box2.label(text="Change Bevel Amount", icon='MOD_BEVEL')
        box2.prop(scene, "jatix_change_bevel", slider=True)

        row = box2.row(align=True)
        row.operator("jatix.change_bevel", text="Apply", icon='CHECKMARK')


# =========================================================
# Registration
# =========================================================

classes = (
    JATIX_OT_ChangeBevel,
    JATIX_PT_ChangeBevelPanel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.jatix_change_bevel = bpy.props.FloatProperty(
        name="Change Bevel",
        description="0 = remove bevel, higher = keep/move bevel",
        default=1.0,
        min=0.0,
    )


def unregister():
    del bpy.types.Scene.jatix_change_bevel
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
