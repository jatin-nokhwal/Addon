import bpy
import os

def create_folders_for_scene_materials(output_directory):
    all_materials = {mat.name for mat in bpy.data.materials if mat.users > 0}
    
    for material_name in all_materials:
        material_folder_path = os.path.join(output_directory, material_name)
        subfolders = ["Textures", "Maps", "Mesh"]
        
        if not os.path.exists(material_folder_path):
            os.makedirs(material_folder_path)
        for subfolder in subfolders:
            subfolder_path = os.path.join(material_folder_path, subfolder)
            if not os.path.exists(subfolder_path):
                os.makedirs(subfolder_path)

def export_objects_to_fbx(output_directory):
    for material in bpy.data.materials:
        if material.users == 0:
            continue
        
        linked_objects = [
            obj for obj in bpy.data.objects 
            if obj.type == 'MESH' and material.name in [
                slot.material.name for slot in obj.material_slots if slot.material
            ]
        ]
        
        if not linked_objects:
            continue
        
        material_folder = os.path.join(output_directory, material.name, "Mesh")
        if not os.path.exists(material_folder):
            os.makedirs(material_folder)
        
        bpy.ops.object.select_all(action='DESELECT')
        for obj in linked_objects:
            obj.select_set(True)
        
        bpy.context.view_layer.objects.active = linked_objects[0]
        
        fbx_path = os.path.join(material_folder, f"{material.name}.fbx")
        bpy.ops.export_scene.fbx(
            filepath=fbx_path,
            use_selection=True,
            apply_unit_scale=True,
            bake_space_transform=True,
            object_types={'MESH'},
            use_mesh_modifiers=True,
            mesh_smooth_type='FACE',
            apply_scale_options='FBX_SCALE_UNITS'
        )

class PREPARE_OT_FileForPainter(bpy.types.Operator):
    """Prepare File for Painter"""
    bl_idname = "export.prepare_file_for_painter"
    bl_label = "Prepare File For Painter"
    bl_options = {'REGISTER', 'UNDO'}
    
    directory: bpy.props.StringProperty(
        name="Export Directory",
        subtype='DIR_PATH'
    )

    def execute(self, context):
        if not self.directory:
            self.report({'ERROR'}, "No export directory selected.")
            return {'CANCELLED'}
        
        create_folders_for_scene_materials(self.directory)
        export_objects_to_fbx(self.directory)
        self.report({'INFO'}, "Files exported successfully.")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class VIEW3D_PT_ExportFile(bpy.types.Panel):
    """Panel for Exporting Files"""
    bl_label = "EXPORT FILE"
    bl_idname = "VIEW3D_PT_Export_File"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'

    def draw(self, context):
        layout = self.layout
        layout.operator("export.prepare_file_for_painter", text="Prepare File For Painter", icon="BRUSH_DATA")
