bl_info = {
    "name": "JaTiX Tools Pack",
    "author": "Jatin Nokhwal",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > N-Panel > JaTiX Tools",
    "description": "Small, focused utilities for hard-surface & game-asset workflows",
    "category": "3D View",
}

import bpy
import os
import math

from bpy.props import (
    BoolProperty,
    StringProperty,
    EnumProperty,
    FloatProperty,
    PointerProperty,
)

# ------------------------------------------------------------------------
# Imports
# ------------------------------------------------------------------------

from .apply_weighted_normal import (
    OBJECT_OT_apply_modifiers,
    OBJECT_OT_set_auto_smooth,
    VIEW3D_PT_apply_modifiers_panel,
    update_auto_smooth_angle,
)

from .reset_cursor_rotation import (
    ResetCursorRotation,
    VIEW3D_PT_CursorTools,
)

from .udim_material_processor import (
    PROCESS_OT_Materials,
    VIEW3D_PT_Materials,
)

from .prepare_file_for_painter import (
    PREPARE_OT_FileForPainter,
    VIEW3D_PT_ExportFile,
)

from .jtx_simple_lattice import (
    Op_LatticeCreateOperator,
    Op_LatticeApplyOperator,
    Op_LatticeRemoveOperator,
    MODIFIERSTRENGTH_PG_main,
    RESOLUTIONUVW_PG_main,
    prepend_menus,
    append_menus,
    context_menu,
    object_mesh_menu,
)

# ------------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------------

addon_keymaps = []


def get_prefs():
    addon = bpy.context.preferences.addons.get(__package__)
    return addon.preferences if addon else None


def clear_keymaps():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except:
            pass
    addon_keymaps.clear()


def parse_key_string(key_str):
    key_str = key_str.strip()
    if not key_str:
        return None

    shift = ctrl = alt = False
    key = None

    for part in key_str.split("+"):
        p = part.strip().upper()
        if p == "SHIFT":
            shift = True
        elif p in {"CTRL", "CONTROL"}:
            ctrl = True
        elif p == "ALT":
            alt = True
        else:
            key = p

    return key, shift, ctrl, alt


def register_keymap(operator_idname, shortcut):
    kc = bpy.context.window_manager.keyconfigs.addon
    if not kc:
        return

    parsed = parse_key_string(shortcut)
    if not parsed:
        return

    key, shift, ctrl, alt = parsed
    km = kc.keymaps.new(name="3D View", space_type='VIEW_3D')
    kmi = km.keymap_items.new(
        operator_idname,
        type=key,
        value='PRESS',
        shift=shift,
        ctrl=ctrl,
        alt=alt,
    )
    addon_keymaps.append((km, kmi))


def rebuild_keymaps():
    clear_keymaps()
    prefs = get_prefs()
    if not prefs:
        return

    if prefs.enable_normal_tools:
        register_keymap(
            OBJECT_OT_apply_modifiers.bl_idname,
            prefs.shortcut_apply_weighted,
        )

    if prefs.enable_cursor_tools:
        register_keymap(
            ResetCursorRotation.bl_idname,
            prefs.shortcut_reset_cursor,
        )

# ------------------------------------------------------------------------
# Operators
# ------------------------------------------------------------------------

class JATIXTOOLS_OT_open_readme(bpy.types.Operator):
    bl_idname = "jatix_tools.open_readme"
    bl_label = "Open README"

    def execute(self, context):
        readme_path = os.path.join(os.path.dirname(__file__), "README.md")
        if not os.path.exists(readme_path):
            self.report({'ERROR'}, "README.md not found")
            return {'CANCELLED'}

        os.startfile(readme_path)
        return {'FINISHED'}


class JATIXTOOLS_OT_copy_to_clipboard(bpy.types.Operator):
    bl_idname = "jatix_tools.copy_to_clipboard"
    bl_label = "Copy to Clipboard"

    value: StringProperty()

    def execute(self, context):
        context.window_manager.clipboard = self.value
        self.report({'INFO'}, "Copied to clipboard")
        return {'FINISHED'}


class JATIXTOOLS_OT_welcome_popup(bpy.types.Operator):
    bl_idname = "jatix_tools.welcome_popup"
    bl_label = "Welcome to JaTiX Tools Pack"

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=520)

    def draw(self, context):
        col = self.layout.column()
        col.label(text="Welcome to JaTiX Tools Pack", icon='INFO')
        col.separator()
        col.label(text="Hard-surface & game-asset workflow utilities.")
        col.separator()
        col.label(text="Configure tools in:")
        col.label(text="Edit → Preferences → Add-ons → JaTiX Tools Pack")

    def execute(self, context):
        return {'FINISHED'}

# ------------------------------------------------------------------------
# Addon Preferences
# ------------------------------------------------------------------------

class JATIXTOOLS_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    ui_tab: EnumProperty(
        items=[
            ('GENERAL', "General", ""),
            ('KEYMAPS', "Keymaps", ""),
            ('ABOUT', "About", ""),
        ],
        default='GENERAL',
    )

    first_run: BoolProperty(default=True)

    enable_normal_tools: BoolProperty(name="Normal Tools", default=False)
    enable_cursor_tools: BoolProperty(name="Cursor Tools", default=False)
    enable_udim_tools: BoolProperty(name="UDIM Tools", default=False)
    enable_export_tools: BoolProperty(name="Export Tools", default=False)

    enable_simple_lattice: BoolProperty(
        name="Simple Lattice",
        default=False,
        update=lambda s, c: toggle_simple_lattice_menus(),
    )

    shortcut_apply_weighted: StringProperty(
        name="Apply Weighted Normal",
        default="Ctrl+W",
        update=lambda s, c: rebuild_keymaps(),
    )

    shortcut_reset_cursor: StringProperty(
        name="Reset Cursor Rotation",
        default="D",
        update=lambda s, c: rebuild_keymaps(),
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "ui_tab", expand=True)

        if self.ui_tab == 'GENERAL':
            box = layout.box()
            box.prop(self, "enable_normal_tools")
            box.prop(self, "enable_cursor_tools")
            box.prop(self, "enable_udim_tools")
            box.prop(self, "enable_export_tools")
            box.prop(self, "enable_simple_lattice")

        elif self.ui_tab == 'KEYMAPS':
            box = layout.box()
            box.prop(self, "shortcut_apply_weighted")
            box.prop(self, "shortcut_reset_cursor")

        else:
            box = layout.box()
            box.label(text="Admin: Jatin Nokhwal", icon='USER')
            box.operator("jatix_tools.open_readme", icon='TEXT')

# ------------------------------------------------------------------------
# Panel Polls
# ------------------------------------------------------------------------

VIEW3D_PT_apply_modifiers_panel.poll = classmethod(
    lambda c, x: get_prefs().enable_normal_tools if get_prefs() else True
)
VIEW3D_PT_CursorTools.poll = classmethod(
    lambda c, x: get_prefs().enable_cursor_tools if get_prefs() else True
)
VIEW3D_PT_Materials.poll = classmethod(
    lambda c, x: get_prefs().enable_udim_tools if get_prefs() else True
)
VIEW3D_PT_ExportFile.poll = classmethod(
    lambda c, x: get_prefs().enable_export_tools if get_prefs() else True
)

# ------------------------------------------------------------------------
# Simple Lattice Menus
# ------------------------------------------------------------------------

def enable_simple_lattice_menus():
    for m in prepend_menus:
        m.prepend(context_menu)
    for m in append_menus:
        m.append(object_mesh_menu)


def disable_simple_lattice_menus():
    for m in prepend_menus:
        try:
            m.remove(context_menu)
        except:
            pass
    for m in append_menus:
        try:
            m.remove(object_mesh_menu)
        except:
            pass


def toggle_simple_lattice_menus():
    prefs = get_prefs()
    if prefs and prefs.enable_simple_lattice:
        enable_simple_lattice_menus()
    else:
        disable_simple_lattice_menus()

# ------------------------------------------------------------------------
# Safe Welcome Popup
# ------------------------------------------------------------------------

def show_welcome_popup():
    prefs = get_prefs()
    if prefs and prefs.first_run:
        bpy.ops.jatix_tools.welcome_popup('INVOKE_DEFAULT')
        prefs.first_run = False
    return None

# ------------------------------------------------------------------------
# Register / Unregister
# ------------------------------------------------------------------------

classes = (
    JATIXTOOLS_Preferences,
    JATIXTOOLS_OT_open_readme,
    JATIXTOOLS_OT_copy_to_clipboard,
    JATIXTOOLS_OT_welcome_popup,

    OBJECT_OT_apply_modifiers,
    OBJECT_OT_set_auto_smooth,
    VIEW3D_PT_apply_modifiers_panel,

    ResetCursorRotation,
    VIEW3D_PT_CursorTools,

    PROCESS_OT_Materials,
    VIEW3D_PT_Materials,

    PREPARE_OT_FileForPainter,
    VIEW3D_PT_ExportFile,

    Op_LatticeCreateOperator,
    Op_LatticeApplyOperator,
    Op_LatticeRemoveOperator,

    MODIFIERSTRENGTH_PG_main,
    RESOLUTIONUVW_PG_main,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # ✅ DEFAULT AUTO SMOOTH = 180°
    bpy.types.Scene.auto_smooth_angle = FloatProperty(
        name="Auto Smooth Angle",
        subtype='ANGLE',
        default=math.pi,  # 180 degrees
        update=update_auto_smooth_angle,
    )

    bpy.types.Scene.MODIFIERSTRENGTH_PG_main = PointerProperty(type=MODIFIERSTRENGTH_PG_main)
    bpy.types.Scene.RESOLUTIONUVW_PG_main = PointerProperty(type=RESOLUTIONUVW_PG_main)

    rebuild_keymaps()
    toggle_simple_lattice_menus()

    bpy.app.timers.register(show_welcome_popup, first_interval=0.5)


def unregister():
    disable_simple_lattice_menus()
    clear_keymaps()

    del bpy.types.Scene.auto_smooth_angle
    del bpy.types.Scene.MODIFIERSTRENGTH_PG_main
    del bpy.types.Scene.RESOLUTIONUVW_PG_main

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
