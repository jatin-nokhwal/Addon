import bpy
from mathutils import Euler

# This must match the addon id you used in __init__.py
ADDON_ID = "JaTiXToolsPack"


def get_prefs():
    """Return this addon's preferences or None if not yet registered."""
    addons = bpy.context.preferences.addons
    if ADDON_ID in addons:
        return addons[ADDON_ID].preferences
    return None


class ResetCursorRotation(bpy.types.Operator):
    """Reset 3D Cursor Rotation"""
    bl_idname = "view3d.reset_cursor_rotation"
    bl_label = "Reset 3D Cursor Rotation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.cursor.rotation_euler = Euler((0, 0, 0), 'XYZ')
        return {'FINISHED'}


class VIEW3D_PT_CursorTools(bpy.types.Panel):
    """Panel for cursor tools"""
    bl_label = "Cursor Tools"
    bl_idname = "VIEW3D_PT_Cursor_Tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()

        # Show shortcut info from preferences if available
        if prefs is not None and getattr(prefs, "shortcut_reset_cursor", ""):
            row = layout.row()
            row.label(
                text=f"Shortcut: {prefs.shortcut_reset_cursor}",
                icon="EVENT_D",
            )

        layout.operator(
            "view3d.reset_cursor_rotation",
            text="Reset 3D Cursor Rotation",
            icon="PIVOT_CURSOR",
        )
