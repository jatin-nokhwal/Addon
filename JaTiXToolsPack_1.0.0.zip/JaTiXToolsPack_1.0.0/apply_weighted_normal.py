import bpy
import math
import addon_utils

# Must match addon id from __init__.py
ADDON_ID = "JaTiXToolsPack"


def get_prefs():
    """Return this addon's preferences or None if not yet registered."""
    addons = bpy.context.preferences.addons
    if ADDON_ID in addons:
        return addons[ADDON_ID].preferences
    return None


# ------------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------------

def get_addon_version_string():
    module_name = ADDON_ID
    for mod in addon_utils.modules():
        if mod.__name__.endswith(module_name):
            info = addon_utils.module_bl_info(mod)
            v = info.get("version", (0, 0, 0))
            return f"{v[0]}.{v[1]}.{v[2]}"
    return "0.0.0"


def parse_key_string(key_str):
    key_str = key_str.strip()
    if not key_str:
        return "", False, False, False

    parts = key_str.split("+")
    shift = ctrl = alt = False
    key = ""

    for p in parts:
        p_up = p.strip().upper()
        if p_up == "SHIFT":
            shift = True
        elif p_up in {"CTRL", "CONTROL"}:
            ctrl = True
        elif p_up == "ALT":
            alt = True
        else:
            key = p_up

    return key, shift, ctrl, alt


# ------------------------------------------------------------------------
# Operators
# ------------------------------------------------------------------------

class OBJECT_OT_apply_modifiers(bpy.types.Operator):
    bl_idname = "object.apply_modifiers"
    bl_label = "Apply Weighted Normal"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply Smooth by Angle and Weighted Normal modifiers"

    def execute(self, context):
        obj = context.active_object

        if obj is None:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}

        if obj.type != 'MESH':
            self.report({'WARNING'}, "Active object is not a mesh")
            return {'CANCELLED'}

        current_mode = context.mode
        was_in_edit_mode = 'EDIT' in current_mode

        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.shade_smooth()
        bpy.ops.mesh.customdata_custom_splitnormals_clear()

        base_modifiers = ["WeightedNormal", "Smooth by Angle", "GeometryNodes"]
        for modifier in list(obj.modifiers):
            if any(modifier.name.startswith(base) for base in base_modifiers):
                bpy.ops.object.modifier_remove(modifier=modifier.name)

        auto_smooth_angle = context.scene.auto_smooth_angle
        bpy.ops.object.shade_auto_smooth(angle=auto_smooth_angle)

        bpy.ops.object.modifier_add(type='WEIGHTED_NORMAL')
        weighted_normal_modifier = obj.modifiers.get("WeightedNormal")
        if weighted_normal_modifier:
            weighted_normal_modifier.mode = 'FACE_AREA_WITH_ANGLE'
            weighted_normal_modifier.keep_sharp = True
            bpy.ops.object.modifier_apply(modifier=weighted_normal_modifier.name)

        smooth_modifiers = [mod for mod in obj.modifiers if mod.name.startswith("Smooth by Angle")]
        for modifier in smooth_modifiers:
            bpy.ops.object.modifier_apply(modifier=modifier.name)

        geometry_nodes_modifiers = [
            mod for mod in obj.modifiers
            if mod.type == 'NODES' and "Smooth by Angle" in mod.name
        ]
        for modifier in geometry_nodes_modifiers:
            bpy.ops.object.modifier_apply(modifier=modifier.name)

        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='EDIT')

        self.report({'INFO'}, "Modifiers applied successfully")
        return {'FINISHED'}


class OBJECT_OT_set_auto_smooth(bpy.types.Operator):
    bl_idname = "object.set_auto_smooth"
    bl_label = "Set Auto Smooth Angle"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set auto smooth angle for selected objects"

    def execute(self, context):
        obj = context.active_object

        if obj is None:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}

        if obj.type != 'MESH':
            self.report({'WARNING'}, "Active object is not a mesh")
            return {'CANCELLED'}

        current_mode = context.mode
        was_in_edit_mode = 'EDIT' in current_mode

        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.shade_smooth()

        auto_smooth_angle = context.scene.auto_smooth_angle
        bpy.ops.object.shade_auto_smooth(angle=auto_smooth_angle)

        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='EDIT')

        auto_smooth_angle_degrees = math.degrees(auto_smooth_angle)
        self.report({'INFO'}, f"Auto smooth angle set to {auto_smooth_angle_degrees:.1f}°")
        return {'FINISHED'}


# ------------------------------------------------------------------------
# Panel
# ------------------------------------------------------------------------

class VIEW3D_PT_apply_modifiers_panel(bpy.types.Panel):
    bl_label = "Normal Tools"
    bl_idname = "VIEW3D_PT_apply_modifiers"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Auto Smooth Settings")
        row = box.row()
        row.prop(context.scene, "auto_smooth_angle", text="Angle")
        row = box.row()
        row.operator("object.set_auto_smooth", text="Set Auto Smooth")

        layout.separator()
        layout.operator("object.apply_modifiers", text="Apply Weighted Normal")


# ------------------------------------------------------------------------
# Scene property update
# ------------------------------------------------------------------------

def update_auto_smooth_angle(self, context):
    # Placeholder for future reactive behavior
    pass
